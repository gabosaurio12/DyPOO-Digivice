package mon.model;

public class AdminUser {
    private String userName;
    private String userPassword;

    public AdminUser(String userName, String userPassword) {
        this.userName = userName;
        this.userPassword = userPassword;
    }
}
