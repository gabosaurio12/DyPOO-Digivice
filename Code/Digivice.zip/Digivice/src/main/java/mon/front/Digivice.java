package mon.front;

import javax.swing.*;

public class Digivice extends JFrame {
    private JTextField searchBar;

    public Digivice() {
        setTitle("Digivice");
        setSize(220, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);
    }
}
